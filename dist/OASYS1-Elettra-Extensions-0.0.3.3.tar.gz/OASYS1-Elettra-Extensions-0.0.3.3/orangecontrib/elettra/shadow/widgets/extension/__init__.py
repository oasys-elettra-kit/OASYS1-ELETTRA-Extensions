# Category description for the widget registry

NAME = "ShadowOui Elettra Extension"

DESCRIPTION = "Widgets for ShadowOui"

BACKGROUND = "#0099cc"

ICON = "icons/LogoElettra_transparent.png"

PRIORITY = 130